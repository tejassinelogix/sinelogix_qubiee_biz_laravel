<?php
//Client Id of REST app
define("CLIENT_ID", "Ad3NzM6j46kMX4klm9NRun8ilKunmncjz9jfPTiYp47gMuM0NR3yi6mrCWRgoL4Q3_3dcIGlp8oohZS9");

//ButtonSource Tracker Code
define("SBN_CODE","PP-DemoPortal-EC-JSV4-php-REST");
?>